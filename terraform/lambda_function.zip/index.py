import json

def lambda_handler(event, context):
    for record in event['Records']:
        payload = json.loads(record['body'])
        print(f"[PROCESSANDO PEDIDO]: {payload}")
    return {"statusCode": 200, "body": "Sucesso"}
